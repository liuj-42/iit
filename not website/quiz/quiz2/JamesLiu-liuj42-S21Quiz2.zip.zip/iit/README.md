# iit
readme for the quiz and this repository

"f.	Make sure you give a detailed description of your design choices, why you made them and how you went about implementing them.  Be descriptive."

**The navigation page for the lab now has the accordion widget from jQuery**

	this enables users to see a brief description of the lab before clicking on the link to the lab and seeing a working example

**The main menu now uses tabs to show the website description and links to the lab navigation/frequently used links page**

	this lets me give a better description of what each tab is

**There are now buttons that will let the user show/hide links, and they will shake if the links are already hidden/shown and the user tries pressing the button again**

For the usage of the jQuery widgets (tab, accordion) I used https://jqueryui.com/, specifically https://jqueryui.com/tabs/#vertical and https://jqueryui.com/accordion/ to base my code off of.
