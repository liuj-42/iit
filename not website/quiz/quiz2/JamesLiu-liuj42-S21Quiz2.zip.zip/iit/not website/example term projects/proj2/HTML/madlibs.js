$(document).ready(function(){
	$("tr:odd").addClass("odd");
});