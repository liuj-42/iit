GitHub id: liu-j42
Discord handle: "᲼᲼#7009"
	(the id is 190556758362685442, if you use the discord search function like "from:190556758362685442" you can see my messages even if I change my "username", but if you copy and paste what is in the quotation marks ("᲼᲼#7009") you should stil be able to find me)

some things about the quiz:
	I also included a screenshot of my code for question 3b so you can see the syntax highlighting if that helps

	For question 4b, I exported the prototype as a .bmpr file named quiz2HCI and also exported it as a pdf called quiz2HCI.pdf, but the pdf does not include the comments that I added. From my testing, the .bmpr file does but it is a little weird.
	I also created the mockup before I added jQuery to the site, so my future planned next steps were what I added with jQuery.

	For question 5a, I assumed that I only needed to provide 3 combined examples of URIs and URLs.