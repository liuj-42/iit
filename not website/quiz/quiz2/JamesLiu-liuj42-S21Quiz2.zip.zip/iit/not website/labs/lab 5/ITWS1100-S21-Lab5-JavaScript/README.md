Lab 5: javascript

Link to my website('s homepage): https://afsws.rpi.edu/AFS/home/94/liuj42/public_html/lab%203/iit/


I thought that this lab was a pretty good way to get my feet wet with javascript, coming from a dual major with cs and itws.
I liked how the professor didn't explicitly say "you have to use this function in order to achieve the results that I want" and just let use use whatever we found on the interent, for me I feel like I learned more about onBlur and onFocus than hearing the professor just talk about those two fuctions for a bit.

I also didnt comment the css file, as I didn't change anything in it.