resources used: w3schools, https://developer.mozilla.org/en-US/docs/Web/HTML/Element, some stackoverflow, lecture slides
image source: https://wmq.frewill.net/css/images/noise.jpg

comments/observations:
    At first I didn't know that I was making my own resume, and instead just used the one from Pamela Evans
    I found that the suggestion of blocking the content out with boxes was useful for formatting the resume, and learned about using <dd> and <dt> from mozilla
    I think that this lab was a good introduction to html and css, and with the information given to us during the lectures, documentation available online, and the fact that we had multiple days to complete this seems pretty reasonable.