link to projects page: https://afsws.rpi.edu/AFS/home/94/liuj42/public_html/lab%203/iit/pages/projects.html

thoughts about the lab:

For both my Atom and RSS feeds, I populated it with links for news and patch notes for som games that I've played recently and also my most recent data structures homework. I think that RSS/Atom feeds are an interesting concept, though it seems like they've been decreasing in popularity (although they are still integral to some people's workflows). I have heard of using RSS feeds to automate the downloading of certain things as soon as they are updated but I never thought to actually try it, I might take a shot at it now that I am more familiar with them though.