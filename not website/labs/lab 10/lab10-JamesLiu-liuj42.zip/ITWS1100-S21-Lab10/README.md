intro to itws lab 10 readme

GitHub id: liu-j42
Discord handle: "᲼᲼#7009"
    (the id is 190556758362685442, if you use the discord search function like "from:190556758362685442" you can see my messages even if I change my "username", but if you copy and paste what is in the quotation marks ("᲼᲼#7009") you should stil be able to find me)

I only added the table part of the actors page on the page for the movies, wasn't sure if I needed to add a "add movie" sort of thing. I also didn't make any changes to the css and reused
the classes for the movie table, which should be fine.
