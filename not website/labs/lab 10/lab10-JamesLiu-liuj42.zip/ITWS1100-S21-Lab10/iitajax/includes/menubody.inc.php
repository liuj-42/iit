
<?php echo buildMenu(); ?>

</div>
<div id="bodyBlock">
  <div id="jsMessages"></div>
