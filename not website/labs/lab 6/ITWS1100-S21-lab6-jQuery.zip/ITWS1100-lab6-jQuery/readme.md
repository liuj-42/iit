Lab 6: JQuery

link to the lab on my website: https://afsws.rpi.edu/AFS/home/94/liuj42/public_html/lab%203/iit/pages/projects/lab6.html

Thoughts about the lab:
I think that this lab was fun. I'm not sure if it was because of my prior
experience with other progamming languages, but javascript and jquery seems 
to be intuitive enough that it wasn't too hard for me to get the hang of.